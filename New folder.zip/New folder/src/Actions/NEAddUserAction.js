export const NEAddUserAction=(input)=>{
    return{
        type:'NORMAL_USER_ENTRY',
        payload:{id:Math.random() * 100,input}
    }
}