export const NEAddUserAction=(input)=>{
    console.log(JSON.stringify(input));
    return{
        type:'NORMAL_USER_ENTRY',
        payload:input
    }
}