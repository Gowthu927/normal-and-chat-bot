export const ChatBotInputAction=(input)=>{
    return{
        type:'CHAT_BOT_INPUT',
        payload:input
    }
}