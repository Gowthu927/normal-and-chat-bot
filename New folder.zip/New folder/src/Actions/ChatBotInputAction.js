export const ChatBotInputAction=(input)=>{
    let ChatBotInputData={};
    console.log(typeof(input));
    let data=input.chatbot.split(" ");
    ChatBotInputData.title=data[0];
    ChatBotInputData.firstName=data[1];
    ChatBotInputData.lastName=data[2];
    console.log(ChatBotInputData);
    return{
        type:'CHAT_BOT_INPUT',
        payload:ChatBotInputData
    }
}