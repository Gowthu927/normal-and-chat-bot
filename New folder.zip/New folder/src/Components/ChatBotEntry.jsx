import React from 'react';

class ChatBotEntry extends React.Component{
    render(){
        return(
            <h3>ChatBotEntry Input</h3>
        );
    }
}
export default ChatBotEntry;

