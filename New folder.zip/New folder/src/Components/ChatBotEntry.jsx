import React from 'react';
import {reduxForm , Field} from 'redux-form';
import {connect} from 'react-redux';
import {ChatBotInputAction} from '../Actions/ChatBotInputAction';

class ChatBotEntry extends React.Component{

    chatBot=(form)=>{
        return(
            <div>
                <div>
                    <label>{form.label}</label>
                </div>
                <div>
                    <input type='text' {...form.input} />
                </div>
                <div>
                    {form.meta.touched && form.meta.error}
                </div>
            </div>
        );        

    }
    onChatBotIPSubmit=(ip)=>{
        this.props.ChatBotInputAction(ip);
    }

    render(){
        let {handleSubmit}=this.props;
        return(
            <div>
                <form onSubmit={handleSubmit(this.onChatBotIPSubmit)} >
                    <Field name='chatbot' label="ChatBot" component={this.chatBot} />
                    <button>submit</button>
                </form>
            </div>
        );
    }
}
const validate=(form)=>{
    let error={};
    console.log(typeof(form.chatbot));
   
    
    if(!form.chatbot){
        error.chatbot="Enter the details";
    }
    else if(form.chatbot.length!==0){
        let act=form.chatbot.split(" ");
        if(act.length!==3){
            error.chatbot="Enter the text in correct format";
        }
    }
    return error;

}
export default reduxForm({validate,form:'ChatBotForm'})(connect(null,{ChatBotInputAction})(ChatBotEntry));

