import React from'react';
import {Link} from 'react-router-dom';


class App extends React.Component{
    render(){
        return (
            <div>
                <div>
                    <Link to='/userlist'><button>User List</button></Link>
                </div>
                <div>
                    <Link to='/normalentry'><button>Normal Entry</button></Link>
                </div>
                <div>
                    <Link to='/chatbotentry'><button>ChatBotEntry</button></Link>
                </div>
            </div> 
        );
    }
}

export default App;