import React from 'react';
import {Field , reduxForm} from 'redux-form';
import {NEAddUserAction} from '../Actions/NEAddUserAction';
import {connect} from 'react-redux';

class NormalEntry extends React.Component{

    titleSelector=(form)=>{
        return(
            <div>
                <div>
                    <label>{form.label}</label>
                </div>
                <div>
                    <input type='text' {...form.input} />
                </div>
                <div>
                    {form.meta.touched && form.meta.error}
                </div>
        </div>
        );
    }
    bodySelector=(form)=>{
        return(
            <div>
                <div>
                    <label>{form.label}</label>
                </div>
                <div>
                    <input type='text' {...form.input} />
                </div>
                <div>
                    {form.meta.touched && form.meta.error}
                </div>
            </div>
        );
    }

    onFormEnter=(out)=>{
        this.props.NEAddUserAction(out);
    }

    render(){
        let {handleSubmit}=this.props;
        return(
            <div>
                <form onSubmit={handleSubmit(this.onFormEnter)} >
                    <Field name='title' label='Title' component={this.titleSelector} />
                    <Field name='firstName' label='First Name' component={this.bodySelector} />
                    <Field name='lastName' label='Last Name' component={this.bodySelector} />
                    <button>Add User</button>
                </form>
            </div>
        );
    }
}
const validate=(form)=>{      
    let error={};
    if(!form.title){
        error.title="enter the title";
    }
    if(!form.firstName){
        error.firstName="enter the firstName";
    }
    if(!form.lastName){
        error.lastName="enter the lastName";
    }
    return error;
}


export default reduxForm({
    validate,
    form:'UserInput'
})(connect(null,{NEAddUserAction})(NormalEntry));