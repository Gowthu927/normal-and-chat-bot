import React from 'react';

const SelectAction =(OldComponent)=>{
    class NewComponent extends React.Component{

        render(){
            return(
                <OldComponent onClick={this.onSelect} />
            );
        }
    }
    return NewComponent
}

export default SelectAction;