import React from 'react';
import {connect} from 'react-redux';

class UsersList extends React.Component{
    renderHelper=()=>{
        console.log(this.props.userList)
        if(Object.keys(this.props.userList).length === 0 && this.props.userList.constructor === Object){
            return (<p>No Users Registered</p>);
        }
    }
    render(){
        console.log(JSON.stringify(this.props.userList))
        return(
            <div>
                {this.renderHelper()}
            </div>
        );
    }
}
const mapStateToProps=(state)=>{

    return { userList : state.userList};
}
export default connect(mapStateToProps)(UsersList);
