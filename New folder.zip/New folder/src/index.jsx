import React from 'react';
import ReactDOM from 'react-dom';
import {Provider} from 'react-redux';
import {createStore} from 'redux';
import reducers from './Reducers';
import App from './Components/App';
import {BrowserRouter, Route ,Switch} from 'react-router-dom';
import ChatBotEntry from './Components/ChatBotEntry';
import NormalEntry from './Components/NormalEntry';
import UsersList from './Components/UsersList';

ReactDOM.render(
    <Provider store={createStore(reducers)}>
        <BrowserRouter>
            <div>
                <Switch>
                    <Route path='/' exact component={App} />
                    <Route path='/userlist' exact component={UsersList} />
                    <Route path='/normalentry' exact component={NormalEntry} />
                    <Route path='/chatbotentry' exact component={ChatBotEntry} />
                </Switch>
            </div>
        </BrowserRouter>
    </Provider>,
    document.getElementById('root')
)