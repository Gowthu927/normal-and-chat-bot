export default (state=0,action)=>{
    switch (action.type) {
        case "NORMAL_USER_ENTRY":
            return state+1;
        case "CHAT_BOT_INPUT":
            return state+1
    
        default:
            return state;
            
    }
}