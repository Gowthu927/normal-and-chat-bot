export default (state={},action)=>{
    switch (action.type) {
        case "NORMAL_USER_ENTRY":
            if(Object.keys(state).length===0){
                console.log('inside');
                return action.payload;
            }else{
                return Object.assign({},state,action.payload)
            }
            
        case "CHAT_BOT_INPUT":
                if(Object.keys(state).length===0){
                    return action.payload
                }else{
                    return Object.assign({},state,action.payload)
                }
        default:
            return state;
    }
}