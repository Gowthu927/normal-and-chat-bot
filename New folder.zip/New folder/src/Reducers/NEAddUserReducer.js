export default (state={},action)=>{
    switch (action.type) {
        case "NORMAL_USER_ENTRY":
            return action.payload;
        default:
            return state;
    }
}