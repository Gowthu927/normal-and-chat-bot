export default (state={},action)=>{
    var len;
    switch (action.type) {
        case "NORMAL_USER_ENTRY":
            {
                len = (Object.keys(state).length)+1;
                return {...state,len:action.payload};
            }
            
        case "CHAT_BOT_INPUT":
            {
                len=(Object.keys(state).length)+1;
                return {...state,len:action.payload};
            }
        default:
            return state;
    }
}