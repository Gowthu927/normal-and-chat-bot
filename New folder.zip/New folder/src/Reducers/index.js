import {combineReducers} from 'redux';
import {reducer as formReducer} from 'redux-form';
import NEAddUserReducer from './NEAddUserReducer';
import NumberOfObj from './NumberOfObj';

export default combineReducers({
    form:formReducer,
    userList:NEAddUserReducer,
    count:NumberOfObj
})