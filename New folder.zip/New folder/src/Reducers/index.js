import {combineReducers} from 'redux';
import {reducer as formReducer} from 'redux-form';
import NEAddUserReducer from './NEAddUserReducer';

export default combineReducers({
    form:formReducer,
    userList:NEAddUserReducer
})